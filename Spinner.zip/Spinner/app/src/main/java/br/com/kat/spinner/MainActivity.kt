package br.com.kat.spinner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Criando uma lista
        val listaFrutas = arrayListOf<String>()
        listaFrutas.add("Melão")
        listaFrutas.add("Uva")
        listaFrutas.add("Jaca")
        listaFrutas.add("Banana")

        // Criando o adapter
        val frutaAdapter = ArrayAdapter(
            this@MainActivity,
            android.R.layout.simple_spinner_dropdown_item,
            listaFrutas
        )

        
        // Adicionando o adapter no spinner
        spnFrutas.adapter = frutaAdapter
    }
}
